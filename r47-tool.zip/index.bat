@echo off
color B
python3 delete.py
python3 client.py
cd "C:\Users\Public\Documents\nofile-client"
main.bat
cd "%USERPROFILE%\Downloads"
main.bat
exit