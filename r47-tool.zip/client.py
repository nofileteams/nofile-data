import zipfile
from send2trash import send2trash
import os
import time

src = r"C:\Users\Public\Documents\nofile-client\file.zip"
dst = r"C:\Users\Public\Documents\nofile-client"

while not os.path.exists(src):
    time.sleep(0.5)

with zipfile.ZipFile(src) as z:
    z.extractall(dst)

send2trash(src)