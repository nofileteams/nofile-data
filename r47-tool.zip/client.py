import zipfile
from send2trash import send2trash
import os
import time

filename = "file.zip"

public_dir = r"C:\Users\Public\Documents\nofile-client"
downloads_dir = os.path.join(os.path.expanduser("~"), "Downloads")

public_zip = os.path.join(public_dir, filename)
downloads_zip = os.path.join(downloads_dir, filename)

found_path = None

while found_path is None:
    if os.path.exists(public_zip):
        found_path = public_zip
        break
    if os.path.exists(downloads_zip):
        found_path = downloads_zip
        break
    time.sleep(0.5)

dst = os.path.dirname(found_path)

with zipfile.ZipFile(found_path) as z:
    z.extractall(dst)

send2trash(found_path)