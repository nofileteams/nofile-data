import os
from send2trash import send2trash

path = r"C:\Users\Public\Documents\nofile-client"
for name in os.listdir(path):
    send2trash(os.path.join(path, name))